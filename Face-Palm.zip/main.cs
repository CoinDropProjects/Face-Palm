using System;

class MainClass {
  public static void Main () 
  {
    Console.Clear();
    Console.WriteLine ("Welcome To Text Adventure!");
    Console.WriteLine();
    Console.WriteLine("To go to the next line of text press 'Enter'...");
    Console.ReadKey();
    Console.Clear();
    Console.WriteLine("Great! Now this game will involve multiple questions in which you need to type the answer to choose.");
    Console.WriteLine();
    Console.WriteLine("Do you see this?");
    Console.WriteLine();
    Console.WriteLine("1. Yes");
    Console.WriteLine("2. No");
    Console.Write("Choice: ");
    string mainChoose1 = Console.ReadLine();

    switch (mainChoose1)
    {
    case "1":
    case "Yes":
    case "yes":

    Console.Clear();
    Console.WriteLine("Okay! You are ready to play. Enjoy!");
    Console.ReadKey();
    LevelOne();
    break;

    case "2":
    case "No":
    case "no":

    Console.Clear();
    Console.WriteLine("If you didn't see it, you wouldn't be able to answer...");
    Console.WriteLine();
    Console.WriteLine("Okay! You are ready to play. Enjoy!");
    Console.ReadKey();
    LevelOne();
    break;
    }
  }

  public static void LevelOne()
  {
    Console.Clear();
    Console.WriteLine("You wake up and there is smoke everywhere.");
    Console.WriteLine();
    Console.WriteLine("1. You start screaming");
    Console.WriteLine("2. You jump out the window");
    Console.WriteLine("3. Stop, Drop, and Roll");
    Console.WriteLine();
    Console.Write("Choice: ");
    string wakeUp = Console.ReadLine();

    switch (wakeUp)
    {
      case "1":
      case "start screaming":
      case "scream":

      Console.Clear();
      Console.WriteLine("As you start to scream you accidentaly inhale the smoke and start to suffocate!");
      Console.ReadKey();
      YouLose();
      break;

      case "2":
      case "jump out":

      Console.Clear();
      int num1 = new System.Random().Next(11);

      if (num1 == 8)
      {
        Console.WriteLine("As you try to jump your blanket tangles you up and you land safely with a thump outside");
        Console.ReadKey();
        LevelTwo();
      } else
      {
       Console.WriteLine("The glass shatters as your flesh is sliced and diced but the broken shards.");
        Console.WriteLine();
        Console.WriteLine("You Lose 3 Health!");
        Console.WriteLine();
        Console.WriteLine("Just kidding there is no health you're just really Dead!");
        Console.ReadKey();
        YouLose();
      }
      break;

      case "3":
      case "stop":
      case "drop":
      case "roll":
      case "stop, drop, and roll":

      Console.Clear();
      Console.WriteLine("You crawl on the floor until you reach the front door.");
      Console.WriteLine();
      Console.WriteLine("You safely make it outside.");
      Console.ReadKey();
      LevelTwo();
      break;
    }
    Console.ReadKey();
  }

  public static void LevelTwo()
  {
    Console.Clear();
    Console.WriteLine("You clean yourself off when you see Rachel (The hottest female in the world) pass by.");
    Console.WriteLine();
    Console.WriteLine("1. Walk up to her.");
    Console.WriteLine("2. Wave at her.");
    Console.WriteLine("3. Mind your own business");
    Console.Write("Choice: ");
    string rachelDeath = Console.ReadLine();

    switch (rachelDeath)
    {
      
    case "1":
    Console.WriteLine("Instant Death! Whats the matter with you! SMH...");
    Console.ReadKey();
    YouLose();
    break;
    case "2":
    Console.WriteLine("She waves back. Your heart stops...");
    Console.ReadKey();
    YouLose();
    break;
    case "3":
    Console.WriteLine("You ignore her and start walking to school.");
    Console.ReadKey();
    LevelThree(); 
    break;
    }
  }

  public static void LevelThree()
  {
      Console.Clear();
      Console.WriteLine("As you start to walk to school you notice alot of kids at parks.");
      Console.WriteLine();
      Console.ReadKey();
      Console.WriteLine("When you arrive you realize they're is not alot of cars in student parking.");
      Console.WriteLine();
      Console.ReadKey();
      Console.WriteLine("You open the school doors.");
      Console.WriteLine();
      Console.WriteLine("1. Turn Around");
      Console.WriteLine("2. Go To Class");
      Console.WriteLine();
      Console.Write("Choice: ");
      string openDoorsChoice = Console.ReadLine();

      switch (openDoorsChoice)
      {
          case "1":

          Console.Clear();
          Console.WriteLine("You start to walk down the stairs.");
          Console.WriteLine();
          Console.WriteLine("You trip and fall.");
          Console.WriteLine();
          Console.WriteLine("The staff start to laugh...");
          Console.ReadKey();
          YouLose();
          break;
          case "2":

          Console.Clear();
          Console.WriteLine("You open the door to your class...");
          Console.WriteLine();
          Console.WriteLine("Its empty, you look at the calendar and it says...");
          Console.WriteLine();
          Console.WriteLine("SATURDAY, APRIL 1, 2019");
          Console.WriteLine();
          Console.WriteLine("FacePalm...");
          Console.ReadKey();
          YouWin();
          break;
      }
  }

  public static void YouWin()
  {
      Console.Clear();
      Console.WriteLine("YOU WIN!");
      Console.WriteLine();
      Console.WriteLine("You got massively pranked LOLOLOLOL!!!");
      Console.WriteLine();
      Console.WriteLine("Would you like to play again?");
      Console.WriteLine();
      Console.WriteLine("1. Yes");
      Console.WriteLine("2. No");
      Console.WriteLine();
      Console.Write("Choice: ");
      string restart = Console.ReadLine();

      switch (restart)
      {
          case "1":

          LevelOne();
          break;

          case "2":

          Console.Clear();
          Console.WriteLine("Bye Bye");
          Console.ReadKey();
          System.Threading.Thread.Sleep(100);
          break;
      }
  }

  public static void YouLose()
  {
    Console.Clear();
    Console.WriteLine("You Die!");
    Console.WriteLine();
    Console.WriteLine("or just got embarresed and ran away...");
    Console.WriteLine();
    Console.WriteLine("Regardess you lose...");
    Console.ReadKey();
    LevelOne();
  }
}