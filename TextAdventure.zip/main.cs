using System;

class MainClass {
  public static void Main () 
  {
    Console.Clear();
    Console.WriteLine ("Welcome To Text Adventure!");
    Console.WriteLine();
    Console.WriteLine("To go to the next line of text press 'Enter'...");
    Console.ReadKey();
    Console.Clear();
    Console.WriteLine("Great! Now this game will involve multiple questions in which you need to type the answer to choose.");
    Console.WriteLine();
    Console.WriteLine("Do you see this?");
    Console.WriteLine();
    Console.WriteLine("1. Yes");
    Console.WriteLine("2. No");
    Console.Write("Choice: ");
    string mainChoose1 = Console.ReadLine();

    switch (mainChoose1)
    {
    case "1":
    case "Yes":
    case "yes":

    Console.Clear();
    Console.WriteLine("Okay! You are ready to play. Enjoy!");
    Console.ReadKey();
    LevelOne();
    break;

    case "2":
    case "No":
    case "no":

    Console.Clear();
    Console.WriteLine("If you didn't see it, you wouldn't be able to answer...");
    Console.WriteLine();
    Console.WriteLine("Okay! You are ready to play. Enjoy!");
    Console.ReadKey();
    LevelOne();
    break;
    }
  }

  public static void LevelOne()
  {
    Console.Clear();
    Console.WriteLine("Thank You for testing out the tutorial level of 'Text Adventure'");
    Console.ReadKey();
    System.Threading.Thread.Sleep(100);
  }
}